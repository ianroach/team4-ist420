(function () {
    "use strict";

    //Main application module
    angular.module('app', ['notes']);

}());