(function () {
    "use strict";

    //Notes module
    angular.module('notes', []);

}());